package com.example.quizeappmvp.ui.result;

public interface ResultContract {
    interface Model {
        int getWrongCount();
        int getCorrectCount();
        int getSkippedCount();
        void clearAllStatistics();
    }
    interface View{
        void describeCorrectCount(int correct, int wrong, int skipped);
        void openChooseActivity();
    }

    interface Presenter{
        void clickBtnMenu();
    }
}
