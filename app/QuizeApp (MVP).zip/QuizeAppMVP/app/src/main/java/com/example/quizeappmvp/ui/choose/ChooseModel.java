package com.example.quizeappmvp.ui.choose;

import com.example.quizeappmvp.repository.AppRepasitory;

public class ChooseModel implements ChooseContract.Model{
    private AppRepasitory repasitory;
    public ChooseModel() {
        repasitory = AppRepasitory.getInstance();
    }

    @Override
    public void loadDataByPos(int pos) {
        repasitory.loadTestsByPos(pos);
    }
}
