package com.example.quizeappmvp.ui.choose;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import com.example.quizeappmvp.R;
import com.example.quizeappmvp.ui.InfoActivity;
import com.example.quizeappmvp.ui.game.GameActivity;

public class ChooseActivity extends AppCompatActivity implements ChooseContract.View {

    ChooseContract.Presenter presenter;
    CardView onaTili;
    CardView Tarix;
    CardView Math;
    AppCompatImageView info;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_choose);
        findView();
        clickEvents();

        presenter = new ChoosePresenter(this);
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.statusBarChooseActivity));
        getWindow().setNavigationBarColor(Color.parseColor("#55A9E7"));
    }

    private void findView() {
        onaTili = findViewById(R.id.btnOnaTili);
        Tarix = findViewById(R.id.btnTarix);
        Math = findViewById(R.id.btnMath);
        info = findViewById(R.id.btnInfo);
    }

    private void clickEvents() {
        onaTili.setOnClickListener(v -> {
            presenter.clickOnaTiliBtn();
        });

        Tarix.setOnClickListener(v -> {
            presenter.clicktarxBtn();
        });

        Math.setOnClickListener(v -> {
            presenter.clickMatemBtn();
        });

        info.setOnClickListener(v -> {
            presenter.clickInfoBtn();
        });
    }

    @Override
    public void startGameActivity() {
        Intent i = new Intent(this, GameActivity.class);
        startActivity(i);
        finish();
    }

    @Override
    public void startInfoActivity() {
        Intent i = new Intent(this, InfoActivity.class);
        startActivity(i);
        finish();
    }
}
